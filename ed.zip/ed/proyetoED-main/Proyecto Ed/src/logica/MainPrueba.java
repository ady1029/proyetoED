package logica;

import cu.edu.cujae.ceis.graph.LinkedGraph;
import cu.edu.cujae.ceis.graph.interfaces.ILinkedWeightedEdgeNotDirectedGraph;

public class MainPrueba {

	 public static void main(String[] args) {
			RedSystem sistema= new RedSystem("Red Social");
			boolean registrado= sistema.registrarse("Jose","123456788", "Cuba", "Ingeniero");
			boolean registrado1= sistema.registrarse("Jose","123456788", "Cuba", "Ingeniero");
			System.out.println(registrado);
			System.out.println(registrado1);
			System.out.println(sistema.login("Jose","123456788"));
			ILinkedWeightedEdgeNotDirectedGraph graph = new LinkedGraph();
			Person a = new Person("sami", "12345678","Cuba", "programadora");
			Person b = new Person("marlon", "1234567","Cuba", "programador");
			Person c = new Person("Adrian", "123456","Cuba", "programador");
			graph.insertVertex(a);
			graph.insertVertex(b);
			graph.insertVertex(c);
			graph.insertEdgeNDG(0, 2);
			graph.insertEdgeNDG(0, 1);
			sistema.setGraph(graph);
			System.out.println("Las islas son: ");
			System.out.println("Sami :  " + sistema.isIsland(a.getNick()));
			System.out.println("Marlon :  " + sistema.isIsland(b.getNick()));
			System.out.println("Adrian :  " + sistema.isIsland(c.getNick()));

		}

}
